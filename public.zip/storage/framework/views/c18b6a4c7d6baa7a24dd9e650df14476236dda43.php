<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice Table new </title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
        /* background-color: #F1F2F3; */
    }

    .invoice-container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        border: 3px solid #ddd;
        /* box-shadow:
            inset 0 -3em 3em rgba(0, 0, 0, 0.1),
            0 0 0 2px rgb(255, 255, 255),
            0.3em 0.3em 1em rgba(0, 0, 0, 0.3); */
    }

    .invoice-header {
        text-align: center;
        margin-bottom: 20px;
    }

    .invoice-table {
        width: 100%;
        border-collapse: collapse;
    }

    .invoice-table th,
    .invoice-table td {
        border: 1px solid #111;
        padding: 8px;
    }

    .invoice-table th {
        background-color: #D3D3D3;
    }

    .total-label {
        text-align: right;
        font-weight: bold;
    }

    .total-amount {
        font-weight: bold;
        color: #cc0000;
    }
</style>

<body>
    <div class="invoice-container">
        <div class="invoice-header">
            <h2 style="text-decoration: underline;">INVOICE</h2>
            <p style="text-align: left;">
                <span style=" width: 50%; text-transform: capitalize; font-weight: 700;">
                    Invoice No:
                    <?php echo e($invoice->invoice_id); ?></span>
            </p>
            <p style="text-align: right;"><span style=" width: 50%; text-transform: capitalize; font-weight: 700;">Date:
                    <?php echo e(date('Y-m-d',strtotime($invoice->created_at))); ?></span></p>
            <p style="text-align: left;"><span style=" text-transform: capitalize; font-weight: 700;">Invoice Of</span>
                : <?php echo e(strtoupper($invoice->name)); ?></p>
            <p style="text-align: left;"><span style="text-transform: capitalize; font-weight: 600;">Shipped /
                    Dispatched in Good Order and Condition vide B/L No. <?php echo e($invoice->bl_no); ?>

                    Dated <?php echo e(date('d M Y',strtotime($invoice->created_at))); ?></span></p>
            <p style="text-align: left;"><span style=" text-transform: capitalize; font-weight: 700;">From</span> :
                <?php echo e($invoice->port_loading); ?></p>
                <p style="text-align: left;"><span style=" text-transform: capitalize; font-weight: 700;">To</span> :
                    <?php echo e($invoice->port_discharge); ?> - on account and risk of</p>
            <p style="text-align: left;"><span style=" text-transform: capitalize; font-weight: 700;">M/S</span> : YI
               <?php echo e($invoice->buyer_name); ?> , <?php echo e($invoice->address); ?>

            </p>
        </div>
        <table class="invoice-table">
            <thead>
                <tr>
                    <th>Marks & No.</th>
                    <th>Description</th>
                    
                    <th>Rate USD</th>
                    <th>Total Amount USD</th>
                </tr>
            </thead>
            <tbody>
                
                <tr>
                    <td></td>
                    <td><?php echo e($invoice->net_weight); ?> M/Tons of <?php echo e(strtoupper($invoice->name)); ?> at the rate of <?php echo e($invoice->rate); ?> per M/Ton <?php echo e($invoice->incoterms); ?></td>
                    
                    <td><?php echo e($invoice->rate); ?></td>
                    <td><?php echo e($invoice->net_weight * $invoice->rate); ?></td>
                </tr>
                <tr>
                    <td>As Per B/L</td>
                    <td>Total Value :</td>
                    
                    <td></td>
                    <td></td>
                </tr>
                <!-- Add more rows as needed -->
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="total-label">Total</td>
                    <td class="total-amount"><?php echo e($invoice->net_weight * $invoice->rate); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- PACKING LIST section start -->

    <div class="invoice-container">
        <div class="invoice-header">
            <h2 style="text-decoration: underline;">PACKING LIST</h2>
            <p style="text-align: left;"><span style=" text-transform: capitalize; font-weight: 700;">Invoice No:
                <?php echo e($invoice->invoice_id); ?></span></p>
            <p style="text-align: right;"><span style="text-transform: capitalize; font-weight: 700;">Date:
                <?php echo e(date('Y-m-d',strtotime($invoice->created_at))); ?></span></p>
            <p style="text-align: center;"><span style=" text-transform: capitalize; font-weight: 500;">The Following
                    Items are loaded as per our Invoice No.  <?php echo e($invoice->invoice_id); ?> Dated   <?php echo e(date('d M Y',strtotime($invoice->created_at))); ?>.</span>
            </p>
            <p> <span style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Details are as
                    under:</p>
            <p style="text-align: left;"><span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Container
                    No</span>. <?php echo e($invoice->container_no); ?></p>
            <p style="text-align: left;"><span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Seal No</span>.
                <?php echo e($invoice->seal_no); ?></p>
        </div>
        <table class="invoice-table">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Gross Weight</th>
                    <th>Net Weight</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;"><?php echo e($invoice->name); ?></td>
                    <td style="text-align: center;"><?php echo e($invoice->gross_weight); ?></td>
                    <td style="text-align: center;"><?php echo e($invoice->net_weight); ?></td>
                </tr>
            </tbody>
        </table>
        <div class="invoice-header">
            <p style="text-align: left;"><span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Total Net
                    Weight</span> : <?php echo e($invoice->net_weight); ?> <?php echo e(strtoupper($invoice->unit_measure)); ?></p>
            <p style="text-align: left;"><span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Total Gross
                    Weight</span> : <?php echo e($invoice->gross_weight); ?> <?php echo e(strtoupper($invoice->unit_measure)); ?></p>
            <p style="text-align: left;"><span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Packages</span> :
                    <?php echo e($invoice->packs); ?> Pieces</p>
            <p style="text-align: left;"><span style=" text-transform: capitalize; font-weight: 700;">SHIPPED ON BOARD
                    ON VESSEL VIDE B/L NO. 160113008404 Dated 14 Apr 2023</span></p>
            <p style="text-align: left;"><span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Loaded on Account
                    of</span> :   <?php echo e($invoice->buyer_name); ?> , <?php echo e($invoice->address); ?>

            </p>
        </div>
    </div>

    <!-- CERTIFICATE OF ORIGIN SECTION START  -->

    <div class="invoice-container">
        <div class="invoice-header">
            <h2 style="text-decoration: underline;">CERTIFICATE OF ORIGIN</h2>
            <p style="text-align: left; font-weight: 700;">Invoice No:    <?php echo e($invoice->invoice_id); ?></p>
            <p style="text-align: right; font-weight: 700;">Date:     <?php echo e(date('Y-m-d',strtotime($invoice->created_at))); ?></p>
        </div>

        <div class="invoice-header">
            <p style="text-align: left;">We hereby certify and declare that <span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">Galvalume
                    Dross</span>
                supplied to
                <span style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">  <?php echo e($invoice->buyer_name); ?> , <?php echo e($invoice->address); ?></span> against our Invoice No.
                <span style="text-decoration: underline; text-transform: capitalize; font-weight: 700;"> <?php echo e($invoice->invoice_id); ?></span>
                Dated
                <span
                    style="text-decoration: underline; text-transform: capitalize; font-weight: 700;">     <?php echo e(date('Y-m-d',strtotime($invoice->created_at))); ?></span>
                is of
                <?php echo e($invoice->origin); ?> origin.
            </p>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\invoiceProject\resources\views/page/invoice/print.blade.php ENDPATH**/ ?>