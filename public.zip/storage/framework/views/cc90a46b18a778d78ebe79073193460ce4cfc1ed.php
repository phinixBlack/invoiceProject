<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="index.html" class="app-brand-link">
            
            
            <img src="<?php echo e(asset('public/logo.jpg')); ?>" style="width: 77px;
            height: 66px;">
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        <li class="menu-item">
            <a href="<?php echo e(route('dashbaord.index')); ?>" class="menu-link" style="text-decoration: none">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?php echo e(route('item.index')); ?>" class="menu-link" style="text-decoration: none;<?php echo e(Route::current()->getName() ==="item.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?>">
                <i class="menu-icon tf-icons bx bxs-package"></i>
                <div data-i18n="Analytics">Item</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?php echo e(route('port.index')); ?>" class="menu-link" style="text-decoration: none;<?php echo e(Route::current()->getName() ==="port.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?>">
                <i class="menu-icon tf-icons bx bxs-ship"></i>
                <div data-i18n="Analytics">Port</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="<?php echo e(route('packageType.index')); ?>" class="menu-link" style="text-decoration: none;<?php echo e(Route::current()->getName() ==="packageType.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?>">
                <i class="menu-icon tf-icons bx bxs-package"></i>
                <div data-i18n="Analytics">Package Type</div>
            </a>
        </li>
        <li class="menu-item">
          <a href="<?php echo e(route('customer.customer.index')); ?>" class="menu-link" style="text-decoration: none ;<?php echo e(Route::current()->getName() ==="customer.customer.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?>">
              <i class="menu-icon tf-icons bx bx-group"></i>
              <div data-i18n="Analytics">Customer</div>
          </a>
      </li>
       <li class="menu-item">
          <a href="<?php echo e(route('invoice.invoice.index')); ?>" class="menu-link" style="text-decoration: none ;<?php echo e(Route::current()->getName() ==="invoice.invoice.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?> "  >
              <i class="menu-icon tf-icons bx bx-detail"></i>
              <div data-i18n="Analytics">Invoice</div>
          </a>
      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('freight.freight.index')); ?>" class="menu-link" style="text-decoration: none ;<?php echo e(Route::current()->getName() ==="freight.freight.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?> "  >
            <i class="menu-icon tf-icons bx bx-detail"></i>
            <div data-i18n="Analytics">Freight</div>
        </a>
    </li>
    <li class="menu-item">
        <a href="<?php echo e(route('bank.bank.index')); ?>" class="menu-link" style="text-decoration: none ;<?php echo e(Route::current()->getName() ==="bank.bank.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?> "  >
            <i class="menu-icon tf-icons bx bxs-bank"></i>
            <div data-i18n="Analytics">Banking</div>
        </a>
    </li>
    <li class="menu-item">
        <a href="<?php echo e(route('company.company.index')); ?>" class="menu-link" style="text-decoration: none ;<?php echo e(Route::current()->getName() ==="company.company.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?> "  >
            <i class="menu-icon tf-icons bx bxs-business"></i>
            <div data-i18n="Analytics">Company</div>
        </a>
    </li>
    <li class="menu-item">
        <a href="<?php echo e(route('report.report.index')); ?>" class="menu-link" style="text-decoration: none ;<?php echo e(Route::current()->getName() ==="report.report.index" ?"background-color: rgba(67, 89, 113, 0.04)":""); ?> "  >
            <i class="menu-icon tf-icons bx bxs-report"></i>
            <div data-i18n="Analytics">Report</div>
        </a>
    </li>


    </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\invoiceProject\resources\views/include/sidebar.blade.php ENDPATH**/ ?>