
<?php $__env->startSection('extracss'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagename'); ?>
    <a class="navbar-brand ml-5" style="color: #242423;" href="#">Sales List</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms /</span> Invoice Tab</h4>
        <form id="company_create" method="POST" acton="#">
            <div class="row">
                <!-- Form controls and first invoice tab -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="defaultInput" class="form-label">Company Name</label>
                                <input id="defaultInput" class="form-control" type="text" placeholder="auto or edit...."
                                    name="company_name" value="<?php echo e($company->company_name); ?>" />
                            </div>

                        
                           
                            <div class="mb-3">
                                <label for="defaultInput" class="form-label">City</label>
                                <input id="defaultInput" class="form-control" type="text" placeholder="write...." value="<?php echo e($company->city); ?>" 
                                    name="city"  />
                            </div>
                          
                            <div class="mb-3">
                                <label for="defaultInput" class="form-label">Country</label>
                                <input id="defaultInput" class="form-control" type="text" placeholder="write...." value="<?php echo e($company->country); ?>" 
                                    name="country"  />
                            </div>
                            <div class="mb-3">
                                <label for="defaultInput" class="form-label">Pin Code</label>
                                <input id="defaultInput" class="form-control" type="text" placeholder="write...." value="<?php echo e($company->pin_code); ?>" 
                                    name="pin_code"  />
                            </div>
                            <div class="mb-3">
                                <label for="defaultSelect" class="form-label">Address</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="address" > <?php echo e($company->address); ?></textarea>
                                 

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Second invoice tab -->
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="defaultSelect" class="form-label">Account No</label>
                                <input class="form-control" type="text" value="" id="html5-date-input" value="<?php echo e($company->account_no); ?>" 
                                    name="account_no" placeholder="Invoice date" />
                            </div>
                            <div class="mb-3">
                                <label for="defaultSelect" class="form-label">Bank Name</label>
                                <input id="defaultInput" class="form-control" type="text" placeholder="write...." value="<?php echo e($company->bank_name); ?>" 
                                    name="bank_name" />
                            </div>
                            
                            <div class="mb-3">
                                <label for="defaultSelect" class="form-label">Swift Code</label>
                                <input class="form-control" type="text" value="" id="html5-date-input" value="<?php echo e($company->swift_code); ?>" 
                                    name="swift_code" placeholder="Invoice date" />
                            </div>
                           
                            <div class="mb-3">
                                <label for="defaultSelect" class="form-label">IFSC</label>
                                <input id="defaultInput" class="form-control" type="text" placeholder="write...." value="<?php echo e($company->ifsc); ?>" 
                                    name="ifsc" />

                            </div>
                            <div class="mb-3">
                                <label for="defaultSelect" class="form-label">Bank Address</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="bank_address" > <?php echo e($company->bank_address); ?></textarea>
                                 

                            </div>
                            <input type="hidden" name="company_id"  value="<?php echo e($company->id); ?>">
                            <button type="submit"class="btn btn-primary" style="margin-left: 448px ;margin-top: 10px;">
                                Save
                            </button>

                        </div>
                    </div>
                </div>


            </div>
            
        </form>

        <!--Fourth tab Other Information  -->

    <?php $__env->startSection('js'); ?>
        <script>
          

            $('#company_create').submit(function(e) {
                e.preventDefault();
                var fd = new FormData(this);
                fd.append('_token', "<?php echo e(csrf_token()); ?>");

                $.ajax({
                    url: "<?php echo e(route('company.edit.store')); ?>",
                    type: "post",
                    data: fd,
                    dataType: "JSON",
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        $('.generalsets').prop('disabled', true);
                    },
                    success: function(result) {
                        if (result.status === true) {
                            iziToast.success({
                                message: result.msg,
                                position: 'topRight'
                            });
                            location.href = "<?php echo e(route('company.company.index')); ?>"

                        } else {
                            iziToast.error({
                                message: result.msg,
                                position: 'topRight'
                            });
                        }
                    }
                })
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invoiceProject\resources\views/page/company/edit.blade.php ENDPATH**/ ?>