<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
      }</style>
</head>
<body>
    <table>
        <tr>
            <th>Id</th>
            <th>No Of Container</th>
            <th>Container No / Seal No</th>
            <th>Item</th>
            <th>Quantity(Net weight)</th>
            <th>Origin Country</th>
            <th>Seller Name</th>
            <th>Buying Rate</th>
            <th>Buying Invoice No and Date</th>
            <th>Import BL No and Date</th>
            <th>Merchant company / Trading co</th>
            <th>Port Of Loading</th>
            <th>Port Of Discharge</th>
            <th>Buyer Name</th>
            <th>Selling Rate PMT</th>
            <th>Selling Invoice No</th>
            <th>Selling Invoice Date</th>
            <th>Export BL No.</th>
            <th>Export BL Date</th>
            <th>Incoterm</th>
            <th>Contacts No</th>
            <th>Documentary Credit No /LC No.</th>
            <th>Remarks</th>
            <th>Bank</th>
            <th>Payment Bank Ref No And Date</th>
            <th>Paid Amount</th>
            <th>Receipt Bank Ref No. And Date</th>
            <th>Receipt Amount</th>
            <th>Bank Charge </th>
            <th>Insurance</th>
            <th>Freight</th>
            <th>Profile Margin</th>
        </tr>
        <tr>
        
        </tr>
      
      </table>
</body>
</html>